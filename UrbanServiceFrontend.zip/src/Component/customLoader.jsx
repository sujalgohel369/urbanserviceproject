import React from 'react'

export const customLoader = () => {
  return (
    <div>
      <div class="loader"></div>
    </div>
  );
}
