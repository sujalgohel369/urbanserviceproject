const UserSchema = require("../Models/UserModel");
const mailUtil =require("../Util/MailUtil");
const encrypt = require("../Util/Encrypt");

const createUser = async (req, res) => {
  try {
    const hashedPassword = encrypt.encryptPassword(req.body.password);
    const userObj = {
      name: req.body.name,
      email: req.body.email,
      password: hashedPassword,
      phone: req.body.phone,
      role: req.body.role,
    };
    //maill
    const savedUser = await UserSchema.create(userObj);
    const mailRes = await mailUtil.mailSend(
      savedUser.email,
      "Welcome mail",
      "Welcome to local service..."
    );
    //mail
    res.status(201).json({
      message: "Created user successfully",
      data: savedUser,
      flag: 1,
    });
  } catch (err) {
    res.status(500).json({
      message: "Error in creating user",
      data: err,
      flag: -1,
    });
  }
};

const getAllUser = async (req, res) => {
  try {
    const user = await UserSchema.find()
    res.status(200).json({
      message: "User Fetched",
      flag: 1,
      data: user,
    });
  } catch (error) {
    res.status(500).json({
      message: "Server Error",
      flag: -1,
      data: error,
    });
  }
};

const getUserbyId = async (req, res) => {
  try {
    const id = req.params.id;
    const User = await UserSchema.findById(id);
    res.status(200).json({
      message: "User Fetched",
      flag: 1,
      data: User,
    });
  } catch (error) {
    res.status(500).json({
      message: "Server Error",
      flag: -1,
      data: error,
    });
  }
};

const updateUser = async (req, res) => {
  try {
    const id = req.params.id;
    const updateUser = await UserSchema.findByIdAndUpdate(id,req.body)
    res.status(201).json({
      message: "User Updated successfully",
      flag: 1,
      data: updateUser,
    });
  } catch (error) {
    res.status(500).json({
      message: "Server Error",
      flag: -1,
      data: error,
    });
  }
};

const deleteUser = async (req, res) => {
  try {
    const id = req.params.id;
    const deleteUser = await UserSchema.findByIdAndDelete(id);
    res.status(201).json({
      message: "User Deleted successfully",
      flag: 1,
      data: deleteUser,
    });
  } catch (error) {
    res.status(500).json({
      message: "Server Error",
      flag: -1,
      data: error,
    });
  }
};

const loginUser = async (req, res) => {
  //select * from users where email = ? and password = ?
  //db -->password -->encrypt
  // req.body.password 123456 -->
  try {
    //kunal@gmail.com
    const email = req.body.email;
    const password = req.body.password; //123456

    const userFromEmail = await UserSchema.findOne({ email: email }); //db
    if (userFromEmail != null) {
      console.log("User found");
      const flag = encrypt.comparePassword(
        password,
        userFromEmail.password
      );
      if (flag == true) {
        res.status(200).json({
          message: "User login successfully",
          flag: 1,
          data: userFromEmail,
        });
      } else {
        res.status(404).json({
          message: "User not found",
          flag: -1,
        });
      }
    } else {
      res.status(404).json({
        message: "User not found",
        flag: -1,
      });
    }
  } catch (err) {
    res.status(500).json({
      message: "Error in login User",
      data: err,
      flag: -1,
    });
  }
};

module.exports ={
  getAllUser,
  createUser,
  updateUser,
  deleteUser,
  getUserbyId,
  loginUser
}